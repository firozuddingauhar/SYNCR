package com.mycompany.syncr

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
