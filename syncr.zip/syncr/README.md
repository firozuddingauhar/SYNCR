# syncr

A new Flutter project.

## Getting Started

FlutterFlow projects are built to run on the Flutter _stable_ release.
